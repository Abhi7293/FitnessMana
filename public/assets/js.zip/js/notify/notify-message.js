class NotifyMsg {
  constructor() {
    
  }
   static staticProperty = 'static value';
}